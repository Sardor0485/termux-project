const fs = require('fs');
const ner = JSON.parse(fs.readFileSync(__dirname + '/ner.json','utf8'));

function extractEntities(text){
  const result = {};
  if(!text || typeof text !== 'string') return result;
  const lower = text.toLowerCase();

  // list-based entities
  for(const [label, values] of Object.entries(ner.entities)){
    for(const v of values){
      if(lower.includes(v.toLowerCase())){ result[label] = v; break; }
    }
  }

  // regex patterns
  for(const p of ner.patterns){
    const re = new RegExp(p.pattern, 'i');
    const m = lower.match(re);
    if(m && m.groups){
      result[p.label] = m.groups;
    }
  }
  return result;
}

module.exports = extractEntities;
